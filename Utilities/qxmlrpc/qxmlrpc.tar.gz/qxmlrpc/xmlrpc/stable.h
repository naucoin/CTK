
#ifndef STABLE_H
#define STABLE_H
	#if defined(__cplusplus) and not defined(__OBJC__)		
		#include <QtGui>
		#include <QtXml>
		#include <QtCore>
		#include <QtNetwork>
	#endif
#endif // STABLE_H

