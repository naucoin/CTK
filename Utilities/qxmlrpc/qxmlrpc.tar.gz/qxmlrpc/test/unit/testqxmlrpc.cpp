#include "testqxmlrpc.h"

QTEST_MAIN(TestQXmlRPC)
